SECTION_CHARGE={CHARGE:{key:"C", value:"收费"},FREE:{key:"F", value:"免费"}};
YES_NO={YES:{key:"1", value:"是"},NO:{key:"0", value:"否"}};
COURSE_LEVEL={ONE:{key:"1", value:"初级"},TWO:{key:"2", value:"中级"},THREE:{key:"3", value:"高级"}};
COURSE_CHARGE={CHARGE:{key:"C", value:"收费"},FREE:{key:"F", value:"免费"}};
COURSE_STATUS={PUBLISH:{key:"P", value:"发布"},DRAFT:{key:"D", value:"草稿"}};
FILE_USE={COURSE:{key:"C", value:"课程"},TEACHER:{key:"T", value:"讲师"}};
SMS_USE={REGISTER:{key:"R", value:"注册"},FORGET:{key:"F", value:"忘记密码"}};
SMS_STATUS={USED:{key:"U", value:"已使用"},NOT_USED:{key:"N", value:"未使用"}};

SECTION_CHARGE_ARRAY=[{key:"C", value:"收费"},{key:"F", value:"免费"}];
YES_NO_ARRAY=[{key:"1", value:"是"},{key:"0", value:"否"}];
COURSE_LEVEL_ARRAY=[{key:"1", value:"初级"},{key:"2", value:"中级"},{key:"3", value:"高级"}];
COURSE_CHARGE_ARRAY=[{key:"C", value:"收费"},{key:"F", value:"免费"}];
COURSE_STATUS_ARRAY=[{key:"P", value:"发布"},{key:"D", value:"草稿"}];
FILE_USE_ARRAY=[{key:"C", value:"课程"},{key:"T", value:"讲师"}];
SMS_USE_ARRAY=[{key:"R", value:"注册"},{key:"F", value:"忘记密码"}];
SMS_STATUS_ARRAY=[{key:"U", value:"已使用"},{key:"N", value:"未使用"}];
